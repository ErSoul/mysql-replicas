# CLASSIC MYSQL REPLICA

## DESCRIPTION

This is the simplest replication topology available for MySQL. Must keep in mind the following:

- All MySQL server instances must have a unique SERVER_ID.
- There can only be one source, but there can be n-replicas.
- If changes to the data are committed in any of the replicas, it wont be replicated to all other instances.

In this lab we'll have only two instances of MySQL. One will be the source, the other the replica. The control-node only needs to have the mysql-client installed, and for automation purposes, all configurations are executed from there. However, ideally all of these scripts should be run on their respective instances.

## NOTES

The certificates used by the client should belong to the same Certificate Authority (CA). All servers generate their server and client certificates when deployed. You could use the `client-cert.pem` and `client-key.pem` files on the replica's instances.