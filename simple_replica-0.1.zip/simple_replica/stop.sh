#!/bin/sh

docker compose down --rmi all
