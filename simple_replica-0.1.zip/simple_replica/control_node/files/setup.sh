#!/bin/sh

## Wait for the network devices to be stablished
while ! mysql -h master-node -e "CREATE USER '${REPLICA_USER}'@'%' IDENTIFIED BY '${REPLICA_USER_PASSWORD}'" 2>/dev/null
do
	sleep 5s # Avoid DDOS for retries
	echo "Retrying connection to master..."
done

mysql -h master-node -e "GRANT REPLICATION SLAVE ON *.* TO '${REPLICA_USER}'@'%'"


## OPTIONAL: uncomment when database is running on-the-fly.

# mysql -e "FLUSH TABLES WITH READ LOCK"
# mysqldump > dbdump.db#!/bin/sh

echo "Master node setted up!"

### SLAVE CONFIG

BINLOG_FILE=`mysql -h master-node -e "SHOW MASTER STATUS\G" | awk '$1 == "File:" {print $2}'`
BINLOG_POSITION=`mysql -h master-node -e "SHOW MASTER STATUS\G" | awk '$1 == "Position:" {print $2}'`

while ! mysql -h slave-node -e "SELECT 1" > /dev/null
do
	sleep 5s
	echo "Retrying connection to slave..."
done

mysql -w -h slave-node -e "CHANGE REPLICATION SOURCE TO \
			SOURCE_HOST='master-node',
			SOURCE_USER='${REPLICA_USER}',
			SOURCE_PASSWORD='${REPLICA_USER_PASSWORD}',
			SOURCE_LOG_FILE='${BINLOG_FILE}',
			SOURCE_LOG_POS=${BINLOG_POSITION},
			SOURCE_SSL=1,
			SOURCE_SSL_CA='/certs/ca.pem',
			SOURCE_SSL_CERT='/certs/client-cert.pem',
			SOURCE_SSL_KEY='/certs/client-key.pem'"
			
mysql -h slave-node -e "START REPLICA"

echo "Slave node setted up!"
echo "Adding data to the source/master database..."

mysql -h master-node ${MYSQL_DATABASE} < /tmp/BANK_INFO.sql > /dev/null
mysql -h master-node ${MYSQL_DATABASE} < /tmp/USER_DATA.sql > /dev/null

echo "Done! Now your replica should contain the added data."

# Entrypoint will be PID 1. So when entrypoint is finish running, container will stop. Ergo, keep a shell session opened.
# https://stackoverflow.com/a/41742291/8962524

([ -e /bin/bash ] && /bin/bash "$@") || /bin/sh "$@"